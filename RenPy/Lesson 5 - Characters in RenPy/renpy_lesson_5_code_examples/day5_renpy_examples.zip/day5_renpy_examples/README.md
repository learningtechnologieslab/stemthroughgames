# DAY 5 — Ren'Py Code Examples
## STEM Through Games | Characters in Ren'Py

---

### How to Use These Files

Each `.rpy` file is a standalone Ren'Py script.

To run any example:
1. Open Ren'Py and create (or open) a project
2. Navigate to the project folder and open `game/`
3. Replace the contents of `script.rpy` with the example code
4. Click **Launch Project** in the Ren'Py launcher

---

### File Guide

| File | Purpose | Who It's For |
|------|---------|--------------|
| `01_starter_template.rpy` | Bare minimum — narrator text only, no characters | All students, start here |
| `02_first_character.rpy` | Define one character, show dialogue vs. narrator text | **Main Activity** |
| `03_two_characters.rpy` | Two characters in conversation with narrator beats | **Challenge** |
| `04_common_errors.rpy` | The 3 most common mistakes and how to fix them | Reference / review |
| `05_character_colors.rpy` | Add color to character name labels | Extension (early finishers) |
| `06_full_scene_demo.rpy` | Complete polished scene — all concepts combined | Model / inspiration |
| `07_student_template.rpy` | Fill-in-the-blank template for student's own scene | Guided practice |

---

### Key Syntax Reference

```renpy
# Define a character (put this ABOVE label start)
define a = Character("Alex")

# Define a character with a colored name label
define a = Character("Alex", color="#00BFFF")

# The game entry point
label start:

    # Character dialogue — name appears above text box
    a "This is what Alex says."

    # Narrator text — no name label
    "This is the narrator describing the scene."

    # End the game cleanly
    return
```

---

### Common Mistakes Quick Reference

| Mistake | Fix |
|---------|-----|
| `A "Hello!"` (capital letter) | Use lowercase: `a "Hello!"` |
| `a "Hello!"` (no indent) | Add 4 spaces before: `    a "Hello!"` |
| `define a = character("Alex")` | Capitalize: `Character("Alex")` |
| `define` line inside label block | Move it above `label start:` |

---

### Concepts by Example

- **Narrator text** → Examples 1, 2, 3, 6
- **Character dialogue** → Examples 2, 3, 5, 6
- **Single character** → Example 2
- **Multiple characters** → Examples 3, 5, 6
- **Character name colors** → Example 5
- **Error debugging** → Example 4
- **Student writing practice** → Example 7
