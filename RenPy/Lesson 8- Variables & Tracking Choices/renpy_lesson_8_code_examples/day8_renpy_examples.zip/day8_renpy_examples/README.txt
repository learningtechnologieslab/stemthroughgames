================================================================
  DAY 8 — VARIABLES & TRACKING CHOICES
  STEM Through Games · Ren'Py Programming
  Example Scripts · Teacher README
================================================================

OVERVIEW
--------
This folder contains 7 Ren'Py script files for Day 8.
Each file is a standalone lesson resource. Below is a summary
of what each file teaches and when to use it.


================================================================
  FILE INDEX
================================================================

01_variables_intro.rpy
  ┌─ CONCEPT: What is a variable? Declaring, reading, changing.
  ├─ WHEN TO USE: Direct instruction — show on projector while
  │               typing/narrating each line.
  ├─ SKILLS: default, $, [varname] in dialogue, Boolean/Int/String
  └─ TIME: ~8 minutes of teacher-led walkthrough

02_key_mystery_starter.rpy          ← STUDENT ACTIVITY FILE
  ┌─ CONCEPT: Boolean variable + if/else branching.
  ├─ WHEN TO USE: Hand this to students at minute 22. They fill in
  │               two TODO sections marked clearly in the code.
  ├─ SKILLS: default has_key = False, $ has_key = True, if/else
  └─ TIME: ~18 minutes coding + 3 minutes testing

03_key_mystery_completed.rpy        ← TEACHER REFERENCE
  ┌─ CONCEPT: Same as 02, but completed + Extension A (elif).
  ├─ WHEN TO USE: Show on projector after minute 40, OR give
  │               students who are stuck as a hint resource.
  ├─ SKILLS: if/elif/else, two Boolean variables, and operator
  └─ NOTES: Also includes a logic trace table in the comments.

04_number_variables.rpy
  ┌─ CONCEPT: Integer variables — gold counters, attempt trackers.
  ├─ WHEN TO USE: Extension activity or Day 9 warm-up.
  ├─ SKILLS: +=, -=, >=, >, ==, counter loops, nested if
  └─ CONNECTS TO: Extension B in the main activity.

05_multiple_variables.rpy
  ┌─ CONCEPT: Several variables working together (trust + honesty
  │           + found_map + companion name string).
  ├─ WHEN TO USE: Day 9 preview, advanced extension, or as a
  │               discussion example for "real game" connections
  │               (Mass Effect, Dragon Age, Undertale).
  ├─ SKILLS: and, or, String variables, [varname] in dialogue,
  │           compound conditions, 4-way ending branching
  └─ NOTES: Great for whole-class trace discussion.

06_tracing_exercise.rpy
  ┌─ CONCEPT: Reading code and predicting output WITHOUT running it.
  ├─ WHEN TO USE: Reflection / pencil-and-paper activity.
  │               Can be used as the exit ticket for Day 8.
  ├─ SKILLS: Reading variable state at each step, *, -=, not
  ├─ INCLUDES: A blank trace table and full answer key (in comments).
  └─ TIME: ~5–10 minutes as a class activity.

07_common_bugs.rpy
  ┌─ CONCEPT: The 6 most common student errors with variables.
  ├─ WHEN TO USE: After the activity if many students are stuck,
  │               OR as a debugging mini-lesson on Day 9.
  ├─ BUGS COVERED:
  │     #1  lowercase true / false
  │     #2  missing $ on assignment line
  │     #3  "default" inside a label
  │     #4  typo in variable name
  │     #5  = vs == confusion
  │     #6  indentation errors
  └─ NOTES: Buggy code is in comments; working code is runnable.


================================================================
  HOW TO USE THESE FILES IN REN'PY
================================================================

OPTION A — Replace script.rpy
  1. Open your Ren'Py project folder.
  2. Find the "game" subfolder.
  3. Rename the existing "script.rpy" to "script_backup.rpy".
  4. Copy one of these files into the "game" folder.
  5. Rename it to "script.rpy".
  6. Click "Launch Project" in the Ren'Py launcher.

OPTION B — Add as extra .rpy files
  Ren'Py automatically loads ALL .rpy files in the game folder.
  You can copy any of these files directly into "game/" and
  Ren'Py will pick them up. Make sure there are no duplicate
  "label start:" labels — only one file should define that.

NOTE ON BACKGROUND IMAGES
  These scripts reference backgrounds like "bg_forest",
  "bg_castle_gate", etc. Your project's image folder needs
  to include these files (PNG or JPG).
  If you don't have them, replace scene lines with:
      scene bg black    (or any solid colour)


================================================================
  SUGGESTED LESSON FLOW (50 minutes)
================================================================

  Min  0–07   Warm-up discussion (no file needed)
  Min  7–15   Show 01_variables_intro.rpy on projector
              Teacher types/narrates live
  Min 15–22   Show 03_key_mystery_completed.rpy top section
              Introduce if/elif/else on projector
  Min 22–40   Students work on 02_key_mystery_starter.rpy
              (Early finishers: extensions in file 03 or 04)
  Min 40–43   Show 03_key_mystery_completed.rpy as class review
  Min 43–48   Reflection discussion (no file needed)
  Min 48–50   Exit ticket: print/display 06_tracing_exercise.rpy


================================================================
  STANDARDS NOTE
================================================================

  These files address:
    CSTA 2-AP-11  Named variables that store data
    CSTA 2-AP-12  Programs combining control structures
    ISTE 1c       Computational thinking / decomposition

================================================================
