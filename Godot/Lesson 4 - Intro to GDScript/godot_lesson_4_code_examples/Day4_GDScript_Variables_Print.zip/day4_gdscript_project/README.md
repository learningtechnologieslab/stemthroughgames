# Day 4 — GDScript: Variables & Print
## STEM Through Games | Godot 4.x Project

---

## Quick Start (Students)

1. Open **Godot 4.x**
2. Choose **Import** → select the `project.godot` file in this folder
3. Press **F5** (or the ▶ Play button) to run
4. Look at the **Output panel** at the bottom of the screen
5. Read the output section by section — that's your code talking!

---

## What's in This Project?

```
day4_gdscript_project/
│
├── project.godot              ← Godot project config (open this)
│
├── scenes/
│   └── main.tscn              ← The scene that runs on F5
│
└── scripts/
    ├── main.gd                ← Runs ALL examples in order ⭐ START HERE
    ├── game_variables_demo.gd ← The Step 2 starter script (isolated)
    ├── math_operators.gd      ← All 5 operators with game examples
    └── narrative_intro.gd     ← Extension challenge (early finishers)
```

---

## Scripts at a Glance

### `main.gd` — Start Here
Runs every lesson section in sequence:
- Section 1: The exact starter script from Step 2
- Section 2: Modify & Explore challenges
- Section 3: All 5 math operators (+  -  *  /  %)
- Section 4: Narrative character setup (extension)

### `game_variables_demo.gd` — The Starter Script
The isolated Day 4 starter script. Students can copy this node
into a fresh scene and type the code themselves. Contains
commented-out challenge lines students uncomment one at a time.

### `math_operators.gd` — Deep Dive on Operators
One function per operator. Each uses a real game scenario:
- `+` collecting coins, restoring health
- `-` taking damage, spending coins
- `*` power-ups, level scaling
- `/` splitting loot, reducing damage
- `%` bonus life milestones, looping animations, turn alternation

### `narrative_intro.gd` — Extension Challenge
Full narrative character setup:
- Complete worked example (Zara the Swift)
- Student template section to fill in their own character
- Bonus preview of data types (int, float, String, bool)

---

## How to Try Student Edits

1. Open `scripts/game_variables_demo.gd` in the script editor
2. Change `"Hero"` to your name on the `player_name` line
3. Press F5 — your name appears in the Output panel!
4. Try uncommenting the challenge lines (remove the `#`)
5. Press F5 again to see the difference

---

## Attaching a Script to a Node (Step 1 Practice)

To recreate the "attach a script" experience from scratch:
1. File → New Scene
2. Add a **Node** (click + in the scene tree)
3. Right-click the Node → **Attach Script**
4. Name it anything (e.g. `my_first_script.gd`) → Create
5. Type your variables and print() calls inside `_ready()`
6. Press F5 to run

---

## Math Connection

| GDScript | Math Meaning | Game Example |
|----------|-------------|--------------|
| `score + 10` | Addition | Collecting a coin |
| `health - 25` | Subtraction | Taking damage |
| `damage * 2` | Multiplication | Power-up doubles hits |
| `coins / 4` | Division | Split loot 4 ways |
| `score % 100` | Remainder | Bonus life every 100pts |

---

## Lesson Standards
- **CSTA 2-AP-11** — Variables representing different data types
- **CCSS 6.EE.A.2** — Numerical expressions with whole numbers
- **CCSS 6.EE.B.6** — Variables to represent numbers and write expressions

---

## Up Next: Day 5 — Conditionals & Player Input
```gdscript
if health <= 0:
    print("Game Over!")
else:
    print("Keep going!")
```
